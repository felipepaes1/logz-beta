import { PageSpinner } from "@/components/ui/page-spinner"

export default function Loading() {
  return <PageSpinner />
}
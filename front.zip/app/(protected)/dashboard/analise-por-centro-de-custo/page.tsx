export default function DashboardHome() {
  return (
    <section className="p-6">
      <h1 className="text-2xl font-semibold">Dashboard – Análise por Centro de Custo</h1>
      {/* widgets ou cards resumidos aqui */}
    </section>
  )
}
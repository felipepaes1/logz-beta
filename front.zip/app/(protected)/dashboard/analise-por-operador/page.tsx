export default function DashboardPerOperator() {
  return (
    <section className="p-6">
      <h1 className="text-2xl font-semibold">Dashboard – Análise por Colaboradores</h1>
      {/* widgets ou cards resumidos aqui */}
    </section>
  )
}
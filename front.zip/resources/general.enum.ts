export enum MonthEnum {
    JAN = 'JAN',
    FEB = 'FEB',
    MARCH = 'MARCH',
    APRIL = 'APRIL',
    MAY = 'MAY',
    JUNE = 'JUNE',
    JULY = 'JULY',
    AUG = 'AUG',
    SEPT = 'SEPT',
    OCT = 'OCT',
    NOV = 'NOV',
    DEC = 'DEC',
}

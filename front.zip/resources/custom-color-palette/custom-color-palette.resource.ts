import { BaseResource } from '../../base/BaseResource';

export class CustomColorPaletteResource extends BaseResource {
    public static tableName: string = 'custom_color_palletes';
    public static jsonApiType: string;
}

export enum CollaboratorStatusEnum {
    INVITED = 'INVITED',
    ACCEPTED = 'ACCEPTED'
}

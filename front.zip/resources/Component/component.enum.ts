export enum ComponentTypeEnum {
    IN = 'IN',
    OUT = 'OUT'
}

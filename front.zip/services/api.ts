// const api_url = 'https://api.logztech.com.br';
const api_url = process.env.NEXT_PUBLIC_API_URL ?? 'http://127.0.0.1:8000';

export default api_url;
